import { Directive, Injector } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { BaseResourceModel } from '../models/base-resource.model';
import { BaseResourceService } from '../services/base-resource.service';

@Directive()
export abstract class BaseResourceGridComponent<T extends BaseResourceModel> {
  
  public view: any;
  public formGroup: FormGroup;
  public resources: T[] = [];
  protected formBuilder: FormBuilder | undefined;
  public clearFormSubscription = new Subscription();

  constructor(
    protected injector: Injector,
    public resource: T,
    protected resourceService: BaseResourceService<T>,
    protected createFormGroupFn: (dataItem?: any) => FormGroup,
    protected actions: { [key: string]: any },
    protected store: Store
  ) {
    this.formGroup = createFormGroupFn();
  }

  public ngOnInit() {
    this.store.dispatch(this.actions.loadA());
    this.clearFormSubscription = this.resourceService.clearForm$.subscribe(
      () => {
        alert("Credit Card Created Successfuly");
        this.formGroup.reset();
      }
    );
  }

  public save() {
    this.resource = this.formGroup.value;
    if (this.resource.id === null) {
      this.store.dispatch(this.actions.createA({ data: this.resource }));
    }
  }

  public sendPayment() {
    this.resource = this.formGroup.value;
    if (this.resource.id === null) {
      this.store.dispatch(this.actions.send({ data: this.resource }));
    }
  }

  public delete(id: number | undefined) {
    this.store.dispatch(this.actions.deleteA({ id: id }));
  }
}
