import { CreditCard } from 'src/app/models/creditcard.model';
import { Injectable, Injector } from '@angular/core';
import { Subject } from 'rxjs';
import { BASE_URL } from './api-baseUrl';
import { BaseResourceService } from './base-resource.service';

@Injectable({
  providedIn: 'root',
})
export class CreditCardService extends BaseResourceService<CreditCard> {
  constructor(protected injector: Injector) {
    super(`${BASE_URL}/creditCards`, injector, CreditCard.fromJson);
  }
}
