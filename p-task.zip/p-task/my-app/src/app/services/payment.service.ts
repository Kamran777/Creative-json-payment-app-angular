import { Payment } from './../models/payment.model';
import { Injectable, Injector } from '@angular/core';
import { BASE_URL } from './api-baseUrl';
import { BaseResourceService } from './base-resource.service';

@Injectable({
  providedIn: 'root',
})
export class PaymentService extends BaseResourceService<Payment> {
  constructor(protected injector: Injector) {
    super(`${BASE_URL}/payments`, injector, Payment.fromJson);
  }
}
