export class CreditCard {
  constructor(
    public id?: number,
    public creditCardNumber?: string,
    public cardHolder?: string,
    public expirationDate?: string,
    public securityCode?: string,
    public amount?: number
  ) {}
  static fromJson(jsonData: any): CreditCard {
    return Object.assign(new CreditCard(jsonData.id), jsonData);
  }
}
