import { CreditCard } from 'src/app/models/creditcard.model';

export class Payment {
    constructor(
      public id?: number,
      public creditCard?: CreditCard,
      public amount?: number
    ) {}
    static fromJson(jsonData: any): Payment {
      return Object.assign(new Payment(jsonData.id), jsonData);
    }
  }
  