import { PaymentComponent } from './components/payment/payment.component';
import { MyCardComponent } from './components/my-card/my-card.component';
import { AddCardComponent } from './components/add-card/add-card.component';
import { HomeComponent } from './components/home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
  },
  { path: 'add-card', component: AddCardComponent },
  { path: 'my-cards', component: MyCardComponent },
  { path: 'payment', component: PaymentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
