import { creditCardActions } from './../../ngrx/actions/creditcard.action';
import { getAllCreditCards } from './../../ngrx/selectors/creditcard.selectors';
import { CreditCardService } from './../../services/creditcard.service';
import { CreditCard } from 'src/app/models/creditcard.model';
import { Component, OnInit, Injector } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { BaseResourceGridComponent } from 'src/app/shared/base-resource-grid.component';
import { CreditCardValidator } from 'angularx-cc-library';

const createFormGroup = (dataItem?: CreditCard) => {
  if (dataItem) {
    return new FormGroup({
      id: new FormControl(dataItem.id),
      creditCardNumber: new FormControl(dataItem.creditCardNumber),
      cardHolder: new FormControl(dataItem.cardHolder),
      expirationDate: new FormControl(dataItem.expirationDate),
      securityCode: new FormControl(dataItem.securityCode),
    });
  }
  return new FormGroup({
    id: new FormControl(),
    creditCardNumber: new FormControl('', [
      Validators.required,
      Validators.minLength(16),
      CreditCardValidator.validateCCNumber,
    ]),
    cardHolder: new FormControl('', [Validators.required]),
    expirationDate: new FormControl('', [
      Validators.required,
      CreditCardValidator.validateExpDate,
    ]),
    securityCode: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(3),
    ]),
  });
};

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./add-card.component.scss'],
})
export class AddCardComponent
  extends BaseResourceGridComponent<CreditCard>
  implements OnInit {
  creditCards$: Observable<CreditCard[]> = this.store.pipe(
    select(getAllCreditCards)
  );
  public clearFormSubscription = new Subscription();
  constructor(
    protected injector: Injector,
    protected creditCardService: CreditCardService,
    protected store: Store
  ) {
    super(
      injector,
      new CreditCard(),
      creditCardService,
      createFormGroup,
      creditCardActions,
      store
    );
  }
}
