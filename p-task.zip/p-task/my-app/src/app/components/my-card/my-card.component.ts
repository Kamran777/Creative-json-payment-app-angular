import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BaseResourceGridComponent } from "src/app/shared/base-resource-grid.component";
import { creditCardActions } from './../../ngrx/actions/creditcard.action';
import { CreditCardService } from './../../services/creditcard.service';
import { getAllCreditCards } from './../../ngrx/selectors/creditcard.selectors';
import { Component, OnInit, Injector } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { CreditCard } from 'src/app/models/creditcard.model';

const createFormGroup = (dataItem?: CreditCard) => {
  if (dataItem) {
    return new FormGroup({
      id: new FormControl(dataItem.id),
      creditCardNumber: new FormControl(dataItem.creditCardNumber),
      cardHolder: new FormControl(dataItem.cardHolder),
      expirationDate: new FormControl(dataItem.expirationDate),
      securityCode: new FormControl(dataItem.securityCode),
      amount: new FormControl(dataItem.amount)
    });
  }
  return new FormGroup({
    id: new FormControl(),
    creditCardNumber: new FormControl(''),
    cardHolder: new FormControl(''),
    expirationDate: new FormControl(''),
    securityCode: new FormControl(''),
    amount: new FormControl('')
  });
}

@Component({
  selector: 'app-my-card',
  templateUrl: './my-card.component.html',
  styleUrls: ['./my-card.component.scss']
})
export class MyCardComponent extends BaseResourceGridComponent<CreditCard> implements OnInit {

  creditCards$: Observable<CreditCard[]> = this.store.pipe(select(getAllCreditCards));
  public clearFormSubscription = new Subscription();
  
  constructor(
    protected injector: Injector,
    protected creditCardService: CreditCardService,
    protected store: Store
  ) {
    super(
      injector,
      new CreditCard(),
      creditCardService,
      createFormGroup,
      creditCardActions,
      store
    );
  }

}
