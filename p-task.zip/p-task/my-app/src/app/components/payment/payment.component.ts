import { creditCardActions } from 'src/app/ngrx/actions/creditcard.action';
import { AddCardComponent } from './../add-card/add-card.component';
import { getAllPayments } from './../../ngrx/selectors/payment.selectors';
import { paymentActions } from './../../ngrx/actions/payment.action';
import { Payment } from './../../models/payment.model';
import { CreditCardService } from './../../services/creditcard.service';
import { BaseResourceGridComponent } from 'src/app/shared/base-resource-grid.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CreditCard } from 'src/app/models/creditcard.model';
import { Component, OnInit, Injector } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import { getAllCreditCards } from 'src/app/ngrx/selectors/creditcard.selectors';
import { PaymentService } from 'src/app/services/payment.service';

const createFormGroup = (dataItem?: Payment) => {
  if (dataItem) {
    return new FormGroup({
      id: new FormControl(dataItem.id),
      creditCard: new FormControl(dataItem.creditCard),
      amount: new FormControl(dataItem.amount),
    });
  }
  return new FormGroup({
    id: new FormControl(),
    creditCard: new FormControl('', Validators.required),
    amount: new FormControl('', [Validators.required, Validators.min(1)]),
  });
};

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
})
export class PaymentComponent
  extends BaseResourceGridComponent<Payment>
  implements OnInit {
  creditCards$: Observable<CreditCard[]> = this.store.pipe(
    select(getAllCreditCards)
  );
  payments$: Observable<Payment[]> = this.store.pipe(select(getAllPayments));
  public clearFormSubscription = new Subscription();

  constructor(
    protected injector: Injector,
    protected paymentService: PaymentService,
    protected creditCardService: CreditCardService,
    protected store: Store
  ) {
    super(
      injector,
      new Payment(),
      paymentService,
      createFormGroup,
      creditCardActions || paymentActions,
      store
    );
  }
}
