// COMPONENTS

import { AddCardComponent } from './components/add-card/add-card.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { MyCardComponent } from './components/my-card/my-card.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { PaymentComponent } from './components/payment/payment.component';

// NGRX

import { paymentFeatureKey, paymentReducer } from './ngrx/reducer/payment.reducer';
import { creditCardReducer, creditCardFeatureKey } from './ngrx/reducer/creditcard.reducer';
import { CreditCardEffects } from './ngrx/effects/creditcard.effects';
import { EffectsModule } from '@ngrx/effects';
import { PaymentEffects } from './ngrx/effects/payment.effects';

// MODULES


import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { CreditCardDirectivesModule } from 'angularx-cc-library';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';



@NgModule({
  declarations: [

    // COMPONENTS
    AddCardComponent,
    AppComponent,
    HomeComponent,
    MyCardComponent,
    NavbarComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,

    // ROUTING
    AppRoutingModule,

    // HTTP
    HttpClientModule,

    // FORMS
    FormsModule,
    ReactiveFormsModule,

    // ANGULAR CREDIT CARD
    CreditCardDirectivesModule,

    // NGRX

    EffectsModule.forFeature([CreditCardEffects,PaymentEffects]),
    StoreModule.forFeature(creditCardFeatureKey, creditCardReducer),
    StoreModule.forFeature(paymentFeatureKey, paymentReducer),
    StoreModule.forRoot({}),
    EffectsModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
