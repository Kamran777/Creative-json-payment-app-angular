import { CreditCard } from 'src/app/models/creditcard.model';
import { Action, createReducer, on } from '@ngrx/store';
import { loadedA } from '../actions/creditcard.action';

export interface CreditCardState {
  creditCards: CreditCard[];
}

export const initialState: CreditCardState = {
  creditCards: [],
};

export const creditCardFeatureKey = 'creditCards';

const _creditCardReducer = createReducer(
  initialState,
  on(loadedA, (state, { creditCards }) => ({
    ...state,
    creditCards: creditCards,
  }))
);

export function creditCardReducer(
  state: CreditCardState | undefined,
  action: Action
) {
  return _creditCardReducer(state, action);
}
