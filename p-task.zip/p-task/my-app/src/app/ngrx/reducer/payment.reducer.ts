import { Payment } from './../../models/payment.model';
import { Action, createReducer, on } from '@ngrx/store';
import { loadedA } from '../actions/payment.action';

export interface PaymentState {
  payments: Payment[];
}

export const initialState: PaymentState = {
  payments: [],
};

export const paymentFeatureKey = 'payment';

const _paymentReducer = createReducer(
  initialState,
  on(loadedA, (state, { payments }) => ({ ...state, payments: payments }))
);

export function paymentReducer(
  state: PaymentState | undefined,
  action: Action
) {
  return _paymentReducer(state, action);
}
