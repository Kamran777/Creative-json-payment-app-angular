import { PaymentState } from './../reducer/payment.reducer';
import { createFeatureSelector, createSelector } from '@ngrx/store';

export const getAllPaymentState = createFeatureSelector<PaymentState>(
  'payments'
);

export const getAllPayments = createSelector(
  getAllPaymentState,
  (state: PaymentState) => state.payments
);
