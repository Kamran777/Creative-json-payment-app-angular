import { CreditCardState } from './../reducer/creditcard.reducer';
import { createFeatureSelector, createSelector } from '@ngrx/store';

export const getAllCreditCardState = createFeatureSelector<CreditCardState>(
  'creditCards'
);

export const getAllCreditCards = createSelector(
  getAllCreditCardState,
  (state: CreditCardState) => state.creditCards
);
