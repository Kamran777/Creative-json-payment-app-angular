import { CreditCard } from 'src/app/models/creditcard.model';
import { createAction, props } from '@ngrx/store';

export const loadA = createAction(
  '[CreditCards List] Load CreditCard List via Service'
);

export const loadedA = createAction(
  '[CreditCards Effect] CreditCard List Loaded Successfully',
  props<{ creditCards: CreditCard[] }>()
);

export const createA = createAction(
  '[Create CreditCard Component] Create CreditCard',
  props<{ data: CreditCard }>()
);

export const deleteA = createAction(
  '[CreditCard List Operations] Delete CreditCard',
  props<{ id: number }>()
);

export const creditCardActions = {
  loadA,
  loadedA,
  createA,
  deleteA,
};
