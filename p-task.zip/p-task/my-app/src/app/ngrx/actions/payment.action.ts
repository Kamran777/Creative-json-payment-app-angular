import { Payment } from './../../models/payment.model';
import { createAction, props } from '@ngrx/store';

export const loadA = createAction(
  '[Payment List] Load Payment List via Service'
);

export const loadedA = createAction(
  '[Payments Effect] Payments List Loaded Successfully',
  props<{ payments: Payment[] }>()
);

export const send = createAction(
  '[Send Payment Component] Send Payment',
  props<{ data: Payment }>()
);

export const paymentActions = {
  loadA,
  loadedA,
  send,
};
