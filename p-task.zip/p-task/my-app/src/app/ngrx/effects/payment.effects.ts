import { paymentActions } from './../actions/payment.action';
import { PaymentService } from './../../services/payment.service';

import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { EMPTY } from 'rxjs';
import { map, mergeMap, catchError, switchMap } from 'rxjs/operators';

@Injectable()
export class PaymentEffects {
  constructor(
    private actions$: Actions,
    private paymentService: PaymentService
  ) {}

  loadPayments$ = createEffect(() =>
    this.actions$.pipe(
      ofType(paymentActions.loadA),
      mergeMap(() =>
        this.paymentService.getAll().pipe(
          map((payments: any) =>
            paymentActions.loadedA({ payments: payments })
          ),
          catchError(() => EMPTY)
        )
      )
    )
  );

  public savePayment$ = createEffect(() =>
    this.actions$.pipe(
      ofType(paymentActions.send),
      switchMap((action) =>
        this.paymentService.save(action.data).pipe(
          map(() => {
            this.paymentService.setClearForm();
            return paymentActions.loadA();
          })
        )
      )
    )
  );
}
