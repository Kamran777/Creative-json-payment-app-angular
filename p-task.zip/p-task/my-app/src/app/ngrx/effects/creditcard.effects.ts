import { CreditCardService } from './../../services/creditcard.service';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { EMPTY, of } from 'rxjs';
import { map, mergeMap, catchError, switchMap } from 'rxjs/operators';
import { creditCardActions } from '../actions/creditcard.action';

@Injectable()
export class CreditCardEffects {
  constructor(
    private actions$: Actions,
    private creditCardService: CreditCardService
  ) {}

  loadCreditCards$ = createEffect(() =>
    this.actions$.pipe(
      ofType(creditCardActions.loadA),
      mergeMap(() =>
        this.creditCardService.getAll().pipe(
          map((creditCards: any) =>
            creditCardActions.loadedA({ creditCards: creditCards })
          ),
          catchError(() => EMPTY)
        )
      )
    )
  );

  public saveCreditCard$ = createEffect(() =>
    this.actions$.pipe(
      ofType(creditCardActions.createA),
      switchMap((action) =>
        this.creditCardService.save(action.data).pipe(
          map(() => {
            this.creditCardService.setClearForm();
            return creditCardActions.loadA();
          })
        )
      )
    )
  );

  public deleteCreditCard$ = createEffect(() =>
    this.actions$.pipe(
      ofType(creditCardActions.deleteA),
      switchMap((action) =>
        this.creditCardService.delete(action.id).pipe(
          map(() => creditCardActions.loadA()),
          catchError((error) => of(creditCardActions.loadA()))
        )
      )
    )
  );
}
