import { creditCardReducer } from '../reducer/creditcard.reducer';
import { CreditCardState } from './../reducer/creditcard.reducer';

export interface AppState {
  creditCards: CreditCardState;
}

export const appReducer = {
  creditCards: creditCardReducer,
};
